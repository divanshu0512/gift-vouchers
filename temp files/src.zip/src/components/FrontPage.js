import { Box, CircularProgress, Typography } from '@mui/material'
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import env from "react-dotenv";


function FrontPage() {

  const [verification, setVerification] = React.useState("");
  const [userId, setUserid] = React.useState("");

  const navigate = useNavigate();

  const location = window.location.search
  const token = location.replace("?home=", " ")
  console.log("window location : ", token);


  async function getData() {


    try {


      const base = env.REACT_APP_UAPI_URL


      const api = await fetch(`${base}/eezibapi`, {
        method: "POST",
        headers: {
          "Content-Type": 'application/json',
          "Accept":"application/jsons",
          "Authorization":`Bearer ${token}`
        },
        body: JSON.stringify({ token })
      });
      const respo = await api.json();
      console.log(respo);
      console.log("token : ",token)
      if (respo.data.message === "Unauthenticated."){
        window.alert("unauthenticated user")
        
        navigate(-1)
      }

      const auth = respo.data;
      const jwt = auth.access_token.original.access_token;
      setVerification(jwt);
      const userDetails = auth.access_token.original.user.id;
      setUserid(userDetails);
      const userName = auth.access_token.original.user.name;
      console.log("user name : ", userName)

      console.log("RESPO data : ", respo);

      jwt && userDetails ? navigate("/products", { state: { data: [{ "jwt": jwt, "userDetails": userDetails, "userName": userName }] } }) : window.location.replace("http://uat.eezib.in/products");

    } catch (error) {
      location.replace("uat.eezib.in/login");
    } }

  React.useEffect(() => {
    !token ? navigate("/products", { state: { data: "fresh_user" } }) : getData()
  }, [])

  return (
    <Box sx={{display:'flex' , alignItems:'center' , justifyContent:'center'}} >
      <Box sx={{display:'flex' , alignItems:'center' , justifyContent:'center', marginTop:'10%'}} >
          <span style={{ display:'flex' , alignItems:'center' , justifyContent:'center' , flexDirection:'column' }} >
            <CircularProgress size="12rem" thickness={1.5} />
              <Typography>Redirecting to Eezib Cards Mania...</Typography>
          </span>
      </Box>
    </Box>
  )
}

export default FrontPage