import { Box, Button, Card, CardActions, CardContent, CardMedia, Chip, CircularProgress, Pagination, Paper, TextField, Typography } from '@mui/material'
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useLocation } from 'react-router-dom';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { SnoozeRounded } from '@mui/icons-material';
import env from 'react-dotenv';


function CashBackOffer({ someData }) {

    const [data, setData] = React.useState([]);
    const [loading, setLoading] = React.useState(false);
    const [search, setSearch] = React.useState('');
    const [page, setPage] = React.useState(1);
    const [auth, setAuth] = React.useState("");
    const [id, setId] = React.useState("");
    const [userName  , setUserName] = React.useState('');
    const [prevData , setPrevData] = React.useState("");

    const location = useLocation();

    React.useEffect(() => {
        try{
            const res = location.state.data;
            setPrevData(res);
            const resp = res[0];
            {
                if (resp !=="fresh_user") {
                const token = resp.jwt
                setAuth(token)

                const userId = resp.userDetails;
                setId(userId);

                const userName = resp.userName;
                setUserName(userName)
            }
        }
        }catch(err){
            window.alert("url cant be accessed directly");
            navigate(-1);
        }
    })
    

    async function tokenData() {
        try{
            setLoading(true);

            const requestOptions = {
                method: 'GET',
                redirect: 'follow'
              };
    
    
              const base = env.REACT_APP_UAPI_URL
              
            // const api = await fetch(`${base}/api/vouchers`,requestOptions);
            const api = await fetch(`http://192.168.0.101:5000/cards`,requestOptions);

            const respo = await api.json();
            console.log("respo : ",respo.data);
            if(!respo.data){
                window.location.reload()
            }
            setData(respo.data);
    
            setLoading(false); 
        }catch(err){
            window.alert("seems api responding slow, wait few minutes");
            window.location.reload();
        }

          

    }

    const handleSearch = () => {
        return data.filter((data) =>
            data.categories.toLowerCase().includes(search) ||
            data.categories.toUpperCase().includes(search) ||
            data.name.toUpperCase().includes(search) ||
            data.name.toLowerCase().includes(search)

        )
    }
    

    const handleCategory = () => {
        return data.filter((data) =>
            data.categories.toLowerCase().includes(someData) ||
            data.categories.toUpperCase().includes(someData)
        )
    }

    React.useEffect(() => {
        tokenData()
    }, [])

    const navigate = useNavigate();


    return (
        <Box className="back" sx={{ padding: '0.1rem', marginTop: '4rem', borderRadius: { lg: "5rem 5rem 0rem 0rem", sm: "3rem 3rem 0rem 0rem ", xs: "1.5rem 1.5rem 0rem 0rem" } }} >
            <Box sx={{ margin: '2rem' }} >


                {
                    !someData ? null :
                        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }} >
                            <Typography sx={{ fontFamily: 'montserrat', fontWeight: 550, textAlign: 'center', fontSize: { lg: "2.4rem", md: "2rem", xs: "1.5rem" } }} >Top Picks For You</Typography>


                            <Box sx={{ marginTop: "2rem", display: 'grid', gridTemplateColumns: { lg: "repeat(4,1fr)", sm: "repeat(2,1fr)", md: "repeat(2,1fr)", xs: "repeat(2,1fr)" }, gridColumnGap: { lg: '1.6rem', sm: "2rem", md: '2rem', xs: '1.3rem' }, gridRowGap: '1rem' }} >


                            {handleCategory()?.slice((page - 1) * 16, (page - 1) * 16 + 16).map((row) => {
                                    return (
                                        <Box sx={{ marginTop: { lg: "3rem", md: "1.8rem", xs: "0rem" } }} >

                                            <Paper onClick={() => navigate(`/voucher`, { state: { data: { row, auth , id} } })} key={row.name} className='scale' elevation={8} sx={{ width: { lg: 280, md: 280, xs: 150 }, height: { lg: 170, md: 170, xs: 90 }, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }} >
                                                <Box key={row.productId} component="img" src={row.imageUrl} sx={{ width: { lg: 280, md: 280, xs: 150 }, borderRadius: 2 }} />
                                            </Paper>
                                            <Typography sx={{ textAlign: 'center', color: '#575555', marginTop: '1rem', fontFamily: 'montserrat', fontWeight: 500, fontSize: { lg: "1rem", md: "1rem", xs: "0.6rem" } }} >{row.name}</Typography>

                                        </Box>
                                    )
                                })
                                }
                              

                            </Box>

                            <Pagination
                                size='small'
                                style={{
                                    width: 'auto',
                                    padding: 50,
                                    display: 'flex',
                                    alignContent: 'center',
                                    justifyContent: 'center'
                                }}
                                variant='outlined'
                                color='warning'
                                count={(handleCategory()?.length / 16).toFixed(0)}
                                onChange={(_, value) => {
                                    setPage(value);
                                    window.scroll(0, 730)
                                }}
                            />
                        </Box>
                }




                <Box sx={{ marginTop: { lg: "2rem", xs: "0rem" } }} >
                    <Typography sx={{ textAlign: 'center', fontFamily: 'crimson text', textShadow:"0px 0px 2px white", color: "white", fontSize: { lg: "3.5rem", sm: "2.5rem", xs: "1.35rem" }, fontWeight: 600 }} >Trending Eezib Cashback Cards</Typography>

                </Box>

                <Box sx={{ marginTop: '1rem' }} >
                    <TextField variant='outlined' color='primary' value={search} onChange={(e) => setSearch(e.target.value.toLowerCase())} fullWidth label="get your favourite voucher" sx={{ marginTop: "0.9rem" }} />
                </Box>

                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', marginTop: 'rem' }} >



                    {
                        loading ? <CircularProgress size="15rem" thickness={1.5} sx={{ color: '#ff9a42', marginTop: "3rem" }} /> :

                            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }} >



                                <Box sx={{ marginTop: "2rem", display: 'grid', gridTemplateColumns: { lg: "repeat(4,1fr)", sm: "repeat(2,1fr)", md: "repeat(3,1fr)", xs: "repeat(2,1fr)" }, gridColumnGap: { lg: '1.5rem', sm: "2rem", md: '4rem', xs: '1rem' }, gridRowGap: '2.5rem' }} >


                                    {handleSearch()?.slice((page - 1) * 16, (page - 1) * 16 + 16).map((row) => {
                                        return (

                                                
                                                <Paper onClick={() => navigate(`/voucher`, { state: { data: { row, auth, id } } })} elevation={8} sx={{ marginTop: { lg: "2rem", md: "1.8rem", xs: "0rem" }, width: { lg: 270, md: 250, sm: 230, xs: 140 }, position:'relative' , display:'inline-block' ,padding: "0.6rem", borderRadius: 2 }} >
                                                    {
                                                        row.discount > 0 ? 
                                                        <Typography sx={{ position:"absolute" , right:0 , border:{lg:'2px solid white' , xs:"1px solid white"} , padding:{lg:"0rem 1.2rem" , xs:"0rem 0.6rem"} , borderRadius:'0.3rem'  , fontFamily:"montserrat" , fontWeight:500 ,background: 'linear-gradient(230deg, #08C8F6, #4D5DFB)' , color:'#fffb00' , fontSize:{lg:"16px" , xs:"12px"} }} >{row.discount}% off</Typography> :
                                                        null

                                                    }
                                                <Paper key={row.name} className='scale' elevation={8} sx={{ overflow: "hidden", width: { lg: 270, md: 250, sm: 230, xs: 140 }, height: { lg: 170, md: 170, sm: 130, xs: 85 }, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }} >
                                                    <Box key={row.productId} component="img" src={row.imageUrl} sx={{ width: { lg: 270, md: 250, sm: 230, xs: 140 }, borderRadius: 2 }} />
                                                </Paper>
                                                <hr />
                                                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                                    <Typography sx={{ textAlign: 'center', color: '#575555', marginTop: '0.5rem', fontFamily: 'montserrat', fontWeight: 500, fontSize: { lg: "1rem", md: "1rem", xs: "0.6rem" } }} >{row.name}</Typography>
                                                    <NavigateNextIcon sx={{ marginLeft: 'auto', marginTop: '0.8rem', fontSize:{xs:"1rem"} }} />
                                                </Box>


                                            </Paper> 
                                         )
                                    })
                                    }



                                </Box>
                            </Box>

                   
                    }
                </Box>

                <Pagination
                    size="small"
                    sx={{
                        // padding:50,
                        width: "auto",
                        display: 'flex',
                        alignContent: 'center',
                        justifyContent: 'center',
                        marginTop: { lg: "4rem", md: "3rem", xs: "1.5rem" }
                    }}
                    variant='outlined'
                    color='secondary'
                    count={(handleSearch()?.length / 16).toFixed(0)}

                    onChange={(_, value) => {
                        setPage(value);
                        window.scroll(0, 730)
                    }}
                />


            </Box>
        </Box>
    )
}

export default CashBackOffer